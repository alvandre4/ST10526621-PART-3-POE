/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.st10526621_part_3_poe;

/**
 *
 * @author schar
 */
public class St10526621_PART_3_POE {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
