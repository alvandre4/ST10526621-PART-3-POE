
package com.mycompany.st10526621_part_3_poe;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Holds the five arrays and every Part 3 operation on them. */
public class MessageManager {

    // The five arrays required by the brief
    private final ArrayList<Message> sentMessages = new ArrayList<>();
    private final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private final ArrayList<Message> storedMessages = new ArrayList<>();
    private final ArrayList<String> messageHashes = new ArrayList<>();
    private final ArrayList<String> messageIDs = new ArrayList<>();

    private final String storageFile;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public MessageManager(String storageFile) {
        this.storageFile = storageFile;
    }

    /** Puts the message in the right array and records its ID and hash. */
    public void addMessage(Message m) {
        String flag = m.getFlag();

        if (Message.SENT.equalsIgnoreCase(flag)) {
            sentMessages.add(m);
        } else if (Message.DISREGARD.equalsIgnoreCase(flag)) {
            disregardedMessages.add(m);
        } else if (Message.STORED.equalsIgnoreCase(flag)) {
            storedMessages.add(m);
        } else {
            throw new IllegalArgumentException("Unknown flag: " + flag);
        }

        messageIDs.add(m.getMessageID());
        messageHashes.add(m.getMessageHash());
    }

    /** Adds a stored message and writes all stored messages to JSON. */
    public void storeMessage(Message m) {
        m.setFlag(Message.STORED);
        addMessage(m);
        saveStoredMessages();
    }

    public void saveStoredMessages() {
        try (Writer w = Files.newBufferedWriter(Paths.get(storageFile))) {
            gson.toJson(storedMessages, w);
        } catch (IOException e) {
            System.out.println("Could not save stored messages: " + e.getMessage());
        }
    }

    /** Reads the JSON file into the Stored Messages array. */
    public void loadStoredMessages() {
        Path path = Paths.get(storageFile);

        if (!Files.exists(path)) {
            return;
        }

        try (Reader r = Files.newBufferedReader(path)) {
            Type listType = new TypeToken<ArrayList<Message>>() { }.getType();
            ArrayList<Message> fromFile = gson.fromJson(r, listType);

            if (fromFile == null) {
                return;
            }

            for (Message m : fromFile) {
                if (!messageIDs.contains(m.getMessageID())) {
                    m.setFlag(Message.STORED);
                    addMessage(m);
                }
            }
        } catch (Exception e) {
            System.out.println("Could not read stored messages: " + e.getMessage());
        }
    }

    public String generateUniqueID() {
        String id;

        do {
            id = Message.generateMessageID();
        } while (messageIDs.contains(id));

        return id;
    }

    /** Zero-based number for the next message. */
    public int nextMessageNumber() {
        return messageIDs.size();
    }

    /** Sender and recipient of all stored messages. */
    public String displaySendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }

        StringBuilder sb = new StringBuilder();

        for (Message m : storedMessages) {
            sb.append("Sender: ")
              .append(m.getSender())
              .append(" | Recipient: ")
              .append(m.getRecipient())
              .append("\n");
        }

        return sb.toString();
    }

    /** Longest stored message. */
    public String getLongestStoredMessage() {
        String longest = "";

        for (Message m : storedMessages) {
            if (m.getMessage().length() > longest.length()) {
                longest = m.getMessage();
            }
        }

        return longest;
    }

    /** Find a message by its ID. */
    public Message searchByMessageID(String id) {
        for (List<Message> list : allLists()) {
            for (Message m : list) {
                if (m.getMessageID().equals(id)) {
                    return m;
                }
            }
        }

        return null;
    }

    /** All sent or stored messages for one recipient. */
    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();

        for (Message m : sentMessages) {
            if (m.getRecipient().equals(recipient)) {
                results.add(m.getMessage());
            }
        }

        for (Message m : storedMessages) {
            if (m.getRecipient().equals(recipient)) {
                results.add(m.getMessage());
            }
        }

        return results;
    }

    /** Delete a message using its hash. */
    public String deleteByHash(String hash) {
        for (ArrayList<Message> list : allLists()) {
            Iterator<Message> it = list.iterator();

            while (it.hasNext()) {
                Message m = it.next();

                if (m.getMessageHash().equals(hash)) {
                    it.remove();

                    messageHashes.remove(m.getMessageHash());
                    messageIDs.remove(m.getMessageID());

                    if (list == storedMessages) {
                        saveStoredMessages();
                    }

                    return "Message: \"" + m.getMessage()
                            + "\" successfully deleted.";
                }
            }
        }

        return "No message found with hash " + hash + ".";
    }

    /** Report of all sent messages. */
    public String displayReport() {
        StringBuilder sb = new StringBuilder("SENT MESSAGES REPORT\n");

        if (sentMessages.isEmpty()) {
            return sb.append("No messages have been sent.\n").toString();
        }

        for (Message m : sentMessages) {
            sb.append("Message Hash: ")
              .append(m.getMessageHash())
              .append("\n")
              .append("Recipient: ")
              .append(m.getRecipient())
              .append("\n")
              .append("Message: ")
              .append(m.getMessage())
              .append("\n\n");
        }

        return sb.toString();
    }

    public ArrayList<String> getSentMessageTexts() {
        return texts(sentMessages);
    }

    public ArrayList<String> getDisregardedMessageTexts() {
        return texts(disregardedMessages);
    }

    public ArrayList<String> getStoredMessageTexts() {
        return texts(storedMessages);
    }

    public ArrayList<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public ArrayList<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public ArrayList<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public ArrayList<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public ArrayList<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }

    private ArrayList<String> texts(List<Message> list) {
        ArrayList<String> out = new ArrayList<>();

        for (Message m : list) {
            out.add(m.getMessage());
        }

        return out;
    }

    private List<ArrayList<Message>> allLists() {
        List<ArrayList<Message>> lists = new ArrayList<>();

        lists.add(sentMessages);
        lists.add(storedMessages);
        lists.add(disregardedMessages);

        return lists;
    }
}
