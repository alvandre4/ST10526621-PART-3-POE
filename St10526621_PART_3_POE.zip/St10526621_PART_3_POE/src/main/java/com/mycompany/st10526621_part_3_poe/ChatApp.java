
package com.mycompany.st10526621_part_3_poe;

import java.util.ArrayList;
import java.util.Scanner;

/** QuickChat console app: register, log in, then use the main menu. */
public class ChatApp {

    private static final Scanner IN = new Scanner(System.in);

    public static void main(String[] args) {
        Login login = new Login();

        System.out.println("=== Register ===");
        while (!login.isRegistered()) {
            String first = ask("First name: ");
            String last = ask("Last name: ");
            String user = ask("Username (max 5 characters, contains _): ");
            String pass = ask("Password (8+ chars, capital, number, special): ");
            String cell = ask("Cell number (e.g. +27834557896): ");
            System.out.println(login.registerUser(first, last, user, pass, cell));
        }

        System.out.println("\n=== Login ===");
        boolean loggedIn = false;

        while (!loggedIn) {
            loggedIn = login.loginUser(
                    ask("Username: "),
                    ask("Password: ")
            );

            System.out.println(login.returnLoginStatus(loggedIn));
        }

        MessageManager manager = new MessageManager("storedMessages.json");
        manager.loadStoredMessages();

        System.out.println("\nWelcome to QuickChat.");

        boolean running = true;

        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");

            switch (ask("Choose an option: ")) {
                case "1":
                    sendMessages(login, manager);
                    break;

                case "2":
                    System.out.println(manager.displayReport());
                    break;

                case "3":
                    running = false;
                    break;

                case "4":
                    storedMessagesMenu(manager);
                    break;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }

        System.out.println("Goodbye!");
    }

    private static void sendMessages(Login login, MessageManager manager) {
        int count = readInt("How many messages do you want to enter? ");

        for (int i = 0; i < count; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + count + " ---");

            String recipient = ask("Recipient cell number (+27...): ");

            while (!Message.isValidCell(recipient)) {
                System.out.println(
                        "Cell phone number is incorrectly formatted or does not "
                        + "contain an international code, please correct the number and try again."
                );

                recipient = ask("Recipient cell number (+27...): ");
            }

            System.out.println("Cell phone number successfully captured.");

            String text = ask("Enter your message (max 250 characters): ");
            String status = Message.checkMessageLength(text);

            while (!status.equals(Message.READY)) {
                System.out.println(status);

                text = ask("Enter your message (max 250 characters): ");
                status = Message.checkMessageLength(text);
            }

            System.out.println(status);

            String flag = null;

            while (flag == null) {
                switch (ask(
                        "1) Send Message  2) Disregard Message  3) Store Message to send later: "
                )) {
                    case "1":
                        flag = Message.SENT;
                        break;

                    case "2":
                        flag = Message.DISREGARD;
                        break;

                    case "3":
                        flag = Message.STORED;
                        break;

                    default:
                        System.out.println("Please enter 1, 2 or 3.");
                }
            }

            Message m = new Message(
                    manager.generateUniqueID(),
                    manager.nextMessageNumber(),
                    login.getUsername(),
                    recipient,
                    text,
                    flag
            );

            if (flag.equals(Message.STORED)) {
                manager.storeMessage(m);
                System.out.println("Message successfully stored.");
            } else {
                manager.addMessage(m);

                System.out.println(
                        flag.equals(Message.SENT)
                                ? "Message successfully sent."
                                : "Message disregarded."
                );
            }

            System.out.println("Message ID: " + m.getMessageID());
            System.out.println("Message Hash: " + m.getMessageHash());
            System.out.println("Recipient: " + m.getRecipient());
            System.out.println("Message: " + m.getMessage());
        }
    }

    private static void storedMessagesMenu(MessageManager manager) {
        boolean back = false;

        while (!back) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search all messages sent or stored for a recipient");
            System.out.println("e) Delete a message using its hash");
            System.out.println("f) Display report");
            System.out.println("g) Back to main menu");

            switch (ask("Choose an option: ").toLowerCase()) {

                case "a":
                    System.out.println(manager.displaySendersAndRecipients());
                    break;

                case "b": {
                    String longest = manager.getLongestStoredMessage();

                    System.out.println(
                            longest.isEmpty()
                                    ? "There are no stored messages."
                                    : "Longest stored message: " + longest
                    );

                    break;
                }

                case "c": {
                    Message m = manager.searchByMessageID(
                            ask("Enter message ID: ")
                    );

                    System.out.println(
                            m == null
                                    ? "No message found with that ID."
                                    : "Recipient: " + m.getRecipient()
                                    + "\nMessage: " + m.getMessage()
                    );

                    break;
                }

                case "d": {
                    ArrayList<String> results =
                            manager.searchByRecipient(
                                    ask("Enter recipient cell number: ")
                            );

                    if (results.isEmpty()) {
                        System.out.println("No messages found for that recipient.");
                    } else {
                        for (String s : results) {
                            System.out.println("- " + s);
                        }
                    }

                    break;
                }

                case "e":
                    System.out.println(
                            manager.deleteByHash(
                                    ask("Enter message hash: ").toUpperCase()
                            )
                    );
                    break;

                case "f":
                    System.out.println(manager.displayReport());
                    break;

                case "g":
                    back = true;
                    break;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    private static String ask(String prompt) {
        System.out.print(prompt);
        return IN.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                return Math.max(0, Integer.parseInt(ask(prompt)));
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }
}
