
package com.mycompany.st10526621_part_3_poe;

import java.util.concurrent.ThreadLocalRandom;

/** One QuickChat message (sent, stored or disregarded). */
public class Message {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";
    public static final int MAX_LENGTH = 250;
    public static final String READY = "Message ready to send.";

    private String messageID;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String flag;
    private String messageHash;

    public Message(String messageID, int messageNumber, String sender,
                   String recipient, String message, String flag) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.flag = flag;
        this.messageHash = createMessageHash();
    }

    public static String generateMessageID() {
        return String.format("%010d",
                ThreadLocalRandom.current().nextLong(10_000_000_000L));
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public static boolean isValidCell(String cell) {
        return cell != null && cell.matches("\\+\\d{10,12}");
    }

    public static String checkMessageLength(String text) {
        int over = text.length() - MAX_LENGTH;
        return over <= 0
                ? READY
                : "Message exceeds " + MAX_LENGTH
                + " characters by " + over
                + ", please reduce size.";
    }

    public String createMessageHash() {
        String[] words = message.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String prefix = messageID.substring(0,
                Math.min(2, messageID.length()));

        return (prefix + ":" + messageNumber + ":" + first + last)
                .toUpperCase();
    }

    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getFlag() { return flag; }
    public void setFlag(String flag) { this.flag = flag; }

    public String getMessageHash() {
        if (messageHash == null) {
            messageHash = createMessageHash();
        }
        return messageHash;
    }
}
