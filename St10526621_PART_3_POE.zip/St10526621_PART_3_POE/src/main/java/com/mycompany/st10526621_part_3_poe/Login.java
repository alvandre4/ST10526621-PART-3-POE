
package com.mycompany.st10526621_part_3_poe;

/** Part 1 login (replace with your own Login class if you prefer). */
public class Login {

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellNumber;
    private boolean registered;

    public boolean checkUserName(String user) {
        return user != null && user.length() <= 5 && user.contains("_");
    }

    public boolean checkPasswordComplexity(String pass) {
        return pass != null && pass.length() >= 8
                && pass.matches(".*[A-Z].*")
                && pass.matches(".*\\d.*")
                && pass.matches(".*[^A-Za-z0-9].*");
    }

    public boolean checkCellPhoneNumber(String cell) {
        return Message.isValidCell(cell);
    }

    public String registerUser(String first, String last, String user,
                               String pass, String cell) {

        if (!checkUserName(user)) {
            return "Username is not correctly formatted, please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(pass)) {
            return "Password is not correctly formatted, please ensure that the password contains "
                    + "at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cell)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        firstName = first;
        lastName = last;
        username = user;
        password = pass;
        cellNumber = cell;
        registered = true;

        return "User successfully registered.";
    }

    public boolean loginUser(String user, String pass) {
        return registered && username.equals(user) && password.equals(pass);
    }

    public String returnLoginStatus(boolean loggedIn) {
        return loggedIn
                ? "Welcome " + firstName + " " + lastName
                + ", it is great to see you again."
                : "Username or password incorrect, please try again.";
    }

    public boolean isRegistered() {
        return registered;
    }

    public String getUsername() {
        return username;
    }
}
